﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using Microsoft.VisualBasic;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PNotebook01
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            double[,] lojas = new double[3, 3];
            double[] media = new double[3];
            double mediag;
            int i = 0, k = 0;
            string auxiliar;


            for (k = 0; k < 3; k++)
            {
                for (i = 0; i < 3; i++)
                {
                    auxiliar = Interaction.InputBox($"Digite os Valores do Notebook " + (k + 1) + " na loja " + (i + 1), "notebook  " + (k + 1));

                    lojas[k,i] = Convert.ToDouble(auxiliar);
                    media[k] += lojas[k, i];
                }
            }
            media[0] = media[0] / 3;
            media[1] = media[1] / 3;
            media[2] = media[2] / 3;
            mediag = (media[0] + media[1] + media[2]) / 3;

            auxiliar = "";

            listBox1.Items.Add("Notebook 1 loja 1 R$ " + lojas[0, 0] + " loja 2 R$ " + lojas[0, 1] + " loja 3 R$ " + lojas[0, 2] + " Media Notebook 1 R$ " + media[0].ToString("N2") + "\n");
            listBox1.Items.Add("Notebook 2 loja 1 R$ " + lojas[1, 0] + " loja 2 R$ " + lojas[1, 1] + " loja 3 R$ " + lojas[1, 2] + " Media Notebook 2 R$ " + media[1].ToString("N2") + "\n");
            listBox1.Items.Add("Notebook 3 loja 1 R$ " + lojas[2, 0] + " loja 2 R$ " + lojas[2, 1] + " loja 3 R$ " + lojas[2, 2] + " Media Notebook 3 R$ " + media[2].ToString("N2") + "\n");
            listBox1.Items.Add("--------------------------------------");
            listBox1.Items.Add("Média geral computadores R$ " + mediag.ToString("N2"));
        }



        private void listBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
        }

        private void button2_Click(object sender, EventArgs e)
        {
            listBox1.Items.Clear();
        }
    }
}

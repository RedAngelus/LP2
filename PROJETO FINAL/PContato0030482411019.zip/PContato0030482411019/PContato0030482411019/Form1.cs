﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.SqlClient;
using System.Data.Sql;
using System.Windows.Forms;

namespace PContato0030482411019
{
    public partial class frmPrincipal : Form
    {
        public static SqlConnection conexao;

        public frmPrincipal()
        {
            InitializeComponent();
        }

        private void frmprincipal_Load(object sender, EventArgs e)
        {
            try
            {
               conexao = new SqlConnection("Data Source=APOLO;Initial Catalog=BD;User ID=BD2411012;PASSWORD=Mimosamel13@");
               conexao.Open();
            }
            catch (Exception)
            {
                MessageBox.Show("Erro ao abrir");
            }
        }

        private void cadastroContatosToolStripMenuItem_Click(object sender, EventArgs e)
        {
            frmContato frm1 = new frmContato();
            frm1.MdiParent = this;
            frm1.WindowState = FormWindowState.Maximized;
            frm1.Show();
        }

        private void sairToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void sobreToolStripMenuItem_Click(object sender, EventArgs e)
        {
            frmSobre frm2 = new frmSobre();
            frm2.MdiParent = this;
            frm2.WindowState = FormWindowState.Maximized;
            frm2.Show();
        }
    }
}
